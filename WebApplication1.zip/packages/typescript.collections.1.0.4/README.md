Each time you make a release, do:

Update Package.nuspec with version

./update.ps1
./build.ps1
./publish.ps1

You must have set your api key with: http://blog.davidebbo.com/2011/03/saving-your-api-key-with-nugetexe.html